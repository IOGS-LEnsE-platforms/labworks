def pbm_to_c_array(pbm_path, array_name="image_data"):
    with open(pbm_path, "rb") as f:
        # Lire l'en-tête PBM (P4 = binaire)
        header = f.readline()
        if header.strip() != b"P4":
            raise ValueError("Le fichier n'est pas un PBM binaire (P4)")

        # Ignorer les commentaires éventuels
        dimensions = b""
        while not dimensions:
            line = f.readline()
            if not line.startswith(b"#"):
                dimensions = line.strip()

        width, height = map(int, dimensions.split())

        # Calcul de la taille en octets par ligne (alignée sur 8 bits)
        row_bytes = (width + 7) // 8

        # Lecture des données binaires de l'image
        image_data = f.read(row_bytes * height)

    # Génération du tableau C
    output = []
    output.append(f"const uint8_t {array_name}[] = {{")
    
    line = "    "
    for i, byte in enumerate(image_data):
        line += f"0x{byte:02X}, "
        if (i + 1) % 12 == 0:  # saut de ligne toutes les 12 valeurs
            output.append(line)
            line = "    "
    if line.strip():
        output.append(line)
    output.append("};")
    
    # Informations sur la taille
    output.append(f"\n// Image: {width} x {height} pixels")
    output.append(f"// Taille du tableau: {len(image_data)} octets\n")
    
    return "\n".join(output)


# Exemple d'utilisation
if __name__ == "__main__":
    pbm_file = "Images/1_1.pbm"  
    c_array_code = pbm_to_c_array(pbm_file, array_name="im1_1")

    with open("Images/image_output_1_1.c", "w") as f:
        f.write(c_array_code)

    print("Tableau C généré dans 'image_output.c'")