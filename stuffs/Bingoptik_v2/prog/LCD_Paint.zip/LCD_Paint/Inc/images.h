/**
  ******************************************************************************
  * @file    Display/LCD_Paint/Inc/save.h 
  * @author  MCD Application Team
  * @brief   This file contains image used for LTDC application.   
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2017 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SAVE_H
#define __SAVE_H

#include "image_output_1_1.h"
#include "image_output_2_1.h"
#include "image_output_3_1.h"
#include "image_output_4_1.h"
#include "image_output_5_1.h"

#define		IMAGE_WIDTH		200
#define		IMAGE_HEIGHT	120
#define		IMAGE_WIDTH_B	IMAGE_WIDTH / 8


#endif /* __SAVE_H */
